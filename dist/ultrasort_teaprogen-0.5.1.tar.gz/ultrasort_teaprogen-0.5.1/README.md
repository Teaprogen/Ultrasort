# Ultrasort
 Sorting program for personal use 


# Theme
 [Thanks Rdbende for theme!](https://github.com/rdbende/Azure-ttk-theme/tree/gif-based/)